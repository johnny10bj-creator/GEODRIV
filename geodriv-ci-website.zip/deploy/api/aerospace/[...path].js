/**
 * Vercel Edge Function: /api/aerospace/[...path]
 * Proxies to Dify Cloud API, injecting GEOLYX token
 */
export const config = { runtime: 'edge' };

export default async function handler(req) {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: {
        'Access-Control-Allow-Origin': 'https://ci.geodriv.com',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
    });
  }

  const url = new URL(req.url);
  const path = url.pathname.replace('/api/aerospace', '/v1') + url.search;
  const difyUrl = `https://api.dify.ai${path}`;

  const headers = new Headers(req.headers);
  headers.set('Host', 'api.dify.ai');
  headers.set('Authorization', 'Bearer app-DFtLD3FbYrc1NLZOanrwe78y');

  const resp = await fetch(difyUrl, { method: req.method, headers, body: req.body });
  const modified = new Response(resp.body, resp);
  modified.headers.set('Access-Control-Allow-Origin', 'https://ci.geodriv.com');
  return modified;
}
