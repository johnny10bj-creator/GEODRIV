/**
 * Vercel Edge Function: /api/feiye/[...path]
 * Proxies to Dify Cloud API, injecting Feiye CI token
 */
export const config = { runtime: 'edge' };

export default async function handler(req) {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: {
        'Access-Control-Allow-Origin': 'https://ci.geodriv.com',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
    });
  }

  const url = new URL(req.url);
  // Strip /api/feiye prefix, prepend /v1
  const path = url.pathname.replace('/api/feiye', '/v1') + url.search;
  const difyUrl = `https://api.dify.ai${path}`;

  const headers = new Headers(req.headers);
  headers.set('Host', 'api.dify.ai');
  headers.set('Authorization', 'Bearer app-690QO6Znw2IvDYBiDRoVBvxL');

  const resp = await fetch(difyUrl, { method: req.method, headers, body: req.body });
  const modified = new Response(resp.body, resp);
  modified.headers.set('Access-Control-Allow-Origin', 'https://ci.geodriv.com');
  return modified;
}
