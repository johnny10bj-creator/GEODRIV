# ci.geodriv.com 部署指南（Vercel）

## 只需 3 步，5 分钟搞定

---

### 第 1 步：部署到 Vercel

1. 打开 https://vercel.com/new
2. 用 **GitHub 登录**（如果没账号会自动注册）
3. 选 **「Upload」**（上传）→ 拖入 `geodriv-ci-website.zip`
4. **Framework Preset** 选 `Other`
5. 点 **「Deploy」**（部署）
6. 等几十秒，部署完成！你会得到一个 `xxx.vercel.app` 临时地址

打开确认主站能显示。

---

### 第 2 步：绑定域名

1. 在 Vercel 项目页面 → **Settings** → **Domains**
2. 输入 `ci.geodriv.com` → 点 Add
3. Vercel 会提示你需要添加一条 DNS 记录，类似：
   ```
   类型: CNAME
   名称: ci
   值:   cname.vercel-dns.com
   ```

---

### 第 3 步：添加 DNS 记录

1. 打开 https://console.dnspod.cn
2. 找到 `geodriv.com` → DNS 管理
3. 添加记录：
   - 主机记录：`ci`
   - 记录类型：`CNAME`
   - 记录值：`cname.vercel-dns.com`
4. 保存，等 1-2 分钟生效

访问 https://ci.geodriv.com 验证。

---

## 验证清单

| 测试 | 预期 |
|------|------|
| https://ci.geodriv.com | GEODRIV 主站正常 |
| https://ci.geodriv.com/feiye | 飞叶情报页 |
| 发送聊天消息 | 能正常对话 |
| https://ci.geodriv.com/aerospace/ | 航天 CI 页 |
| 中英文切换 | 正常 |
| 暗色主题 | 正常 |

全部通过后，香港服务器可以关了。
